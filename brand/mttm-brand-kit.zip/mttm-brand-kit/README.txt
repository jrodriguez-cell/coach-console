MAKE TIME TO MOVE: BRAND KIT

Give this whole kit to any designer, developer or AI chat.

1. mttm-brand-guidelines.pdf / guidelines.md: the rules. Start with section 00 (brand brief and rules for AI assistants).
2. tokens/mttm-brand.css: ONE file for websites. It contains the MTTM Lettering font itself (embedded),
   the colours, the themes and the type classes. Link it and the brand font works with no other font files.
3. fonts/: MTTM Lettering as .otf (install for Canva, Figma, desktop) and .woff2 (websites).
4. logo/: the logo files. Always use these; never retype or redraw the logo.

MTTM Lettering is a custom font that exists only in this kit. Never substitute Michroma or any other typeface.
